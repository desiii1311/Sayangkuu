# jangan merajuk lagi ya

A Pen created on CodePen.

Original URL: [https://codepen.io/Desi-Fitriani/pen/VYYvPRE](https://codepen.io/Desi-Fitriani/pen/VYYvPRE).

